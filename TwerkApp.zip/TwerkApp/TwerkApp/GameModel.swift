//
//  GameModel.swift
//  TwerkApp
//
//  Created by mac on 27.01.18.
//  Copyright © 2018 Filipp. All rights reserved.
//

import Foundation

let NUM_OF_ARROWS = 5

enum Direction {
    case ToLeft
    case ToRight
    case ToUp
    case ToDown
}

enum State {
    case Default
    case Coin
    case Empty
}

class Arrow {
    var Direct: Direction
    var State: State
    init() {
        Direct = .ToUp
        State = .Default
    }
    
    init(random: Bool, empty: Bool){
        Direct = .ToDown
        State = .Default
        if empty {
            State = .Empty
        }
        if (random){
            let forDirect = Int(arc4random_uniform(4))
            switch (forDirect){
            case 0:
                Direct = .ToUp
            case 1:
                Direct = .ToDown
            case 2:
                Direct = .ToLeft
            case 3:
                Direct = .ToRight
            default:
                Direct = .ToDown
            }
        }
    }
    
    func Randomise (ifCoin : Bool) {
        let forDirect = Int(arc4random_uniform(4))
        switch (forDirect){
        case 0:
            Direct = .ToUp
        case 1:
            Direct = .ToDown
        case 2:
            Direct = .ToLeft
        case 3:
            Direct = .ToRight
        default:
            Direct = .ToDown
        }
        if ifCoin {
            let forCoin = Int(arc4random_uniform(10))
                switch (forCoin){
                case 1:
                    State = .Coin
                default:
                    State = .Default
                }
        }
    }
}

class TwerkGame {
    var Arrows = [Arrow]()
    var ifGame: Bool
    var Score: Int
    var bestScore: Int
    var coins: Int
    var ifShowReplay: Bool
    var ifVibration: Bool
    var ifSound: Bool
    var ifShowAds: Bool
    
    init () {
        ifGame = false
        Score = 0
        ifShowReplay = true
        //тут должна быть подгрузка из DataCore или ещё откуда нибудь
        bestScore = 0
        coins = 0
        ifVibration = true
        ifSound = true
        ifShowAds = true
    }
    
    func PrepareForGame () {
        Score = 0
        for _ in 0...NUM_OF_ARROWS {
            Arrows.append(Arrow(random: true, empty: false))
        }
    }
    
    func PlayerEndedTurn (onPosition position: Direction, withDelta delta: Double) {
        //если закончил слишком далеко
        if (delta >= 1.0) {
            EndGame()
            return
        }
        guard let curFirst = Arrows.first else {
            print("problems with PlayerEndedTurn in GameModel")
            return
        }
        if (position == curFirst.Direct){
            RandomiseLastArrow()
            if (curFirst.State == .Coin) {
                coins += 1
            }
            Score += 1
            if (Score > bestScore) {
                bestScore = Score
            }
            Arrows.append(Arrows.removeFirst())
        } else {
            EndGame()
        }
    }
    
    func RandomiseLastArrow () {
        if let curLast = Arrows.last {
            if (Score > 10) {
                curLast.Randomise(ifCoin: true)
            } else {
                curLast.Randomise(ifCoin: false)
            }
        }
    }
    func RandomiseAll (){
        for curArrow in Arrows {
            curArrow.Randomise(ifCoin: false)
        }
    }
    
    func EndGame () {
        ifGame = false
    }
}
