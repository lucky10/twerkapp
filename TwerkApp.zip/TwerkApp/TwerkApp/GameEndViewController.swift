//
//  GameEndViewController.swift
//  TwerkApp
//
//  Created by mac on 11.03.18.
//  Copyright © 2018 Filipp. All rights reserved.
//

import UIKit

class GameEndViewController: UIViewController {
    
    var Game: TwerkGame? = nil
    @IBOutlet weak var ScoreLabel: UILabel!
    @IBOutlet weak var CoinLabel: UILabel!
    @IBOutlet weak var BestScoreLabel: UILabel!
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateVisibleInfo()
        if let game = Game {
            game.Score = 0
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func updateVisibleInfo () {
        if let game = Game {
            ScoreLabel.text = String(game.Score)
            BestScoreLabel.text = String(game.bestScore)
            CoinLabel.text = String(game.coins)
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? GameViewController {
            vc.Game = Game
        }
        if let vc = segue.destination as? SettingsView {
            vc.Game = Game
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
