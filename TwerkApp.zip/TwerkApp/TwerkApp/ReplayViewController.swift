//
//  ReplayViewController.swift
//  TwerkApp
//
//  Created by mac on 11.03.18.
//  Copyright © 2018 Filipp. All rights reserved.
//

import UIKit

class ReplayViewController: UIViewController {
    var Game: TwerkGame? = nil
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    @IBAction func ContinuePlayingPushed(_ sender: UIButton) {
        if let game = Game {
            game.ifShowReplay = false
            game.ifGame = true
        } else {
            print("Some troubles in ContinuePlayingPushed")
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? GameViewController {
            vc.Game = Game
        }
        if let vc = segue.destination as? GameEndViewController {
            vc.Game = Game
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
