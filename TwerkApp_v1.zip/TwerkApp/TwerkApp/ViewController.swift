//
//  ViewController.swift
//  TwerkApp
//
//  Created by mac on 24.01.18.
//  Copyright © 2018 Filipp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var snapForAss: UISnapBehavior!
    var animatorForAss: UIDynamicAnimator!
    
    var SpeedOfTheGame = 2.0
    let Game = TwerkGame()
    var ArrowsView = [UIImageView]()
    var ifPlaying = false
    var DistanceBetweenArrows = CGFloat(60)
    
    @IBOutlet var PanGestureRecognizerOnAss: UIPanGestureRecognizer!
    @IBOutlet weak var AssView: UIView!
    @IBOutlet weak var AssRight: UIImageView!
    @IBOutlet weak var AssLeft: UIImageView!
    @IBOutlet weak var LifesLabel: UILabel!
    @IBOutlet weak var ScoreLabel: UILabel!
    
    var DefaultAssPosition : CGPoint!
    
    var DefaultAssPositionY : CGFloat?
    var DefaultAssPositionX : CGFloat?
    
    @IBOutlet weak var HipRight: UIImageView!
    @IBOutlet weak var HipLeft: UIImageView!
    
    override func viewDidLoad() {
        DefaultAssPositionY = AssView.center.y
        DefaultAssPositionX = AssView.center.x
        
        DefaultAssPosition = AssView.center
        
        DistanceBetweenArrows = CGFloat (self.view.bounds.width/CGFloat(NUM_OF_ARROWS + 1))
        
        Game.PrepareForGame()
        AddArrows()
        UpdateArrowViews()
        UpdateLabels()
        
        animatorForAss = UIDynamicAnimator(referenceView: self.view)
        
        super.viewDidLoad()
    }
    
    //возвращает угол в зависимости от направления
    func GetDegree (dir: Direction) -> CGFloat {
        switch dir {
        case .ToDown:
            return 0.0
        case .ToLeft:
            return (90.0 * .pi) / 180.0
        case .ToRight:
            return (270.0 * .pi) / 180.0
        case .ToUp:
            return (180.0 * .pi) / 180.0
        default:
            return 0.0
        }
    }
    
    //динамически добавляет стрелки вью
    func AddArrows () {
        let pos_y = CGFloat(100)
        let size = CGFloat (40)
        for i in 0...NUM_OF_ARROWS {
            var cur = UIImageView()
            cur.image = #imageLiteral(resourceName: "ArrowBlack")
            cur.center.x = DistanceBetweenArrows * CGFloat(i + 1)
            cur.center.y = pos_y
            cur.bounds.size.width = size
            cur.bounds.size.height = size
            
            ArrowsView.append(cur)
            
            super.view.addSubview(cur)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //сдвиг стрелочек налево на одну, анимация идет до тех пор пока человек играет
    func AnimateArrows () {
        UIView.animate(withDuration: SpeedOfTheGame, delay: 0, options: .curveLinear, animations: {
            for i in 0...NUM_OF_ARROWS {
                self.ArrowsView[i].center.x -= self.DistanceBetweenArrows
            }}, completion: { (finished: Bool) in
                //говорим игре что сдвинулись на одну стрелку
                self.Game.NextTurn()
                self.UpdateAllVisibleInfo()
                for i in 0...NUM_OF_ARROWS {
                    self.ArrowsView[i].center.x += self.DistanceBetweenArrows
                }
                if (self.Game.ifGame) {
                    self.AnimateArrows()
                }
        })
    }
    
    //обновляет вьюшки стрелок в соответствии с логикой
    func UpdateArrowViews () {
        for i in 0...NUM_OF_ARROWS {
            switch Game.Arrows[i].State {
            case .Empty:
                ArrowsView[i].isHidden = true
            case .OutGoingGood:
                ArrowsView[i].isHidden = false
                ArrowsView[i].image = #imageLiteral(resourceName: "ArrowGreen")
            case .OutGoingBad:
                ArrowsView[i].isHidden = false
                ArrowsView[i].image = #imageLiteral(resourceName: "ArrowRed")
            default:
                ArrowsView[i].isHidden = false
                ArrowsView[i].image = #imageLiteral(resourceName: "ArrowBlack")
            }
            ArrowsView[i].transform = CGAffineTransform(rotationAngle: GetDegree(dir: Game.Arrows[i].Direct))
        }
    }

    //обработка жеста над жопой
    @IBAction func handlePand (recognizer: UIPanGestureRecognizer){
        /*guard let DefaultPositionY = DefaultAssPositionY else {
            return
        }
        guard let DefaultPositionX = DefaultAssPositionX else {
            return
        }*/
        let MULTIPLICATOR = CGFloat(0.2)
        let max_delta = CGFloat(30.0)
        let location = recognizer.location(in: self.view)
        var endingPosition = Direction.ToDown
        if let view = recognizer.view {
            //подсчет новых позиций по иску и игреку
            //var newX = DefaultPositionX - (DefaultPositionX - location.x)*MULTIPLICATOR
            /*if (newX < DefaultPositionX - max_delta) {
                newX = DefaultPositionX - max_delta
                endingPosition = .ToLeft
                //recognizer.isEnabled = false
                //recognizer.isEnabled = true
            }
            if (newX > DefaultPositionX + max_delta) {
                newX = DefaultPositionX + max_delta
                endingPosition = .ToRight
                //recognizer.isEnabled = false
                //recognizer.isEnabled = true
            }*/
            
            //var newY = DefaultPositionY - (DefaultPositionY - location.y)*MULTIPLICATOR
            /*if (newY < DefaultPositionY - max_delta) {
                newY = DefaultPositionY - max_delta
                endingPosition = .ToUp
                //recognizer.isEnabled = false
                //recognizer.isEnabled = true
            }
            if (newY > DefaultPositionY + max_delta) {
                newY = DefaultPositionY + max_delta
                endingPosition = .ToDown
                //recognizer.isEnabled = false
                //recognizer.isEnabled = true
            }*/
            
            var newX = DefaultAssPosition.x - (DefaultAssPosition.x - location.x)*MULTIPLICATOR
            var newY = DefaultAssPosition.y - (DefaultAssPosition.y - location.y)*MULTIPLICATOR
            
            view.center = CGPoint(x: newX, y: newY)
        }
        recognizer.setTranslation(CGPoint.zero, in: self.view)
        
        if(recognizer.state == .ended) {
            //Game.PlayerEndedTurn(onPosition: endingPosition)
            /*if (Game.ifGame) {
                AnimateArrows()
            }
            UpdateArrowViews()
            UpdateLabels()*/
            
            //новый способ анимировать жопу
            TwerkV2()
            //Twerk()
        }
    }
    
    func TwerkV2 (){
        if (snapForAss != nil){
            animatorForAss.removeBehavior(snapForAss)
        }
        snapForAss = UISnapBehavior(item: AssView, snapTo: DefaultAssPosition)
        snapForAss.damping = 0.15
        animatorForAss.addBehavior(snapForAss)
        
        //добавить расширение и сужение ягодиц
        let delta = 0.07
        var cur_duration = 0.0
        var cur_delay = delta
        for curNumOfAnimation in 0...2 {
            UIView.animate(withDuration: cur_duration, delay: cur_delay, options: .curveEaseInOut, animations: {
                self.AssLeft.frame.size.width *= 0.8
                self.AssLeft.frame.size.height *= 0.8
                self.AssRight.frame.size.width *= 0.8
                self.AssRight.frame.size.height *= 0.8
            }, completion: nil)
            cur_duration += delta
            cur_delay += delta
            UIView.animate(withDuration: cur_duration, delay: cur_delay, options: .curveEaseInOut, animations: {
                self.AssLeft.frame.size.width /= 0.8
                self.AssLeft.frame.size.height /= 0.8
                self.AssRight.frame.size.width /= 0.8
                self.AssRight.frame.size.height /= 0.8
            }, completion: { (finished: Bool) in
                if(curNumOfAnimation == 2){
                    //self.ifAnimation = true
                }
            })
            cur_duration += delta
            cur_delay += delta
        }
    }
    
    //анимация возвращения жопы в положение равновесия 
    func Twerk () {
        let cur_delta_delta = CGFloat(0.5)
        var cur_delay = 0.0
        var cur_duration = 0.25
        guard let DefaultPositionY = DefaultAssPositionY else {
            return
        }
        guard let DefaultPositionX = DefaultAssPositionX else {
            return
        }
        var cur_deltaY = DefaultPositionY - AssView.center.y
        var sgnY = CGFloat(1.0)
        var cur_deltaX = DefaultPositionX - AssView.center.x
        var sgnX = CGFloat(1.0)
        if DefaultPositionY > AssView.center.y {
            sgnY *= -1
        }
        if DefaultPositionX < AssView.center.x {
            sgnX *= -1
        }
        UIView.animate(withDuration: cur_duration, delay: cur_delay, options: .curveEaseIn, animations: {
            self.AssView.center.y = DefaultPositionY
            self.AssView.center.x = DefaultPositionX
        }, completion: nil)
        
        cur_delay += cur_duration
        for num_of_cur_animation in 1...3 {
            cur_duration *= 0.5
            UIView.animate(withDuration: cur_duration, delay: cur_delay, options: .curveEaseIn, animations: {
                self.AssView.center.y = DefaultPositionY + CGFloat(cur_deltaY * sgnY)
                self.AssView.center.x = DefaultPositionX + CGFloat(cur_deltaX * sgnX)
            }, completion: nil)
            cur_delay += cur_duration
            UIView.animate(withDuration: cur_duration, delay: cur_delay, options: .curveEaseOut, animations: {
                self.AssView.center.y = DefaultPositionY
                self.AssView.center.x = DefaultPositionX
            }, completion: nil)
            cur_delay += cur_duration
            sgnX *= -1
            sgnY *= -1
            cur_deltaX *= cur_delta_delta
            cur_deltaY *= cur_delta_delta
        }
    }
    
    //
    func UpdateLabels () {
        LifesLabel.text = String(Game.Lifes)
        ScoreLabel.text = String(Game.Score)
    }
    
    //
    func UpdateAllVisibleInfo (){
        UpdateArrowViews()
        UpdateLabels()
    }
    
    //игрок сделал игру
    //возможно тут надо добавить обновление какой-нибудь хуйни
    func PlayerMadeHisTurn (dir : Direction) {
        if (!Game.ifGame) {
            AnimateArrows()
        }
        Game.PlayerEndedTurn(onPosition: dir)
        UpdateAllVisibleInfo()
    }
    
    @IBAction func testBtnUp(_ sender: Any) {
        PlayerMadeHisTurn(dir: .ToUp)
    }
    
    @IBAction func testBtnRight(_ sender: Any) {
        PlayerMadeHisTurn(dir: .ToRight)
    }
    
    @IBAction func testBtnDown(_ sender: Any) {
        PlayerMadeHisTurn(dir: .ToDown)
    }
    
    @IBAction func testBtnLeft(_ sender: Any) {
        PlayerMadeHisTurn(dir: .ToLeft)
    }
}

