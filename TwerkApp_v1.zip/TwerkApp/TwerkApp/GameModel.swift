//
//  GameModel.swift
//  TwerkApp
//
//  Created by mac on 27.01.18.
//  Copyright © 2018 Filipp. All rights reserved.
//

import Foundation

let NUM_OF_ARROWS = 3

enum Direction {
    case ToLeft
    case ToRight
    case ToUp
    case ToDown
}

enum State {
    case UpComing
    case Current
    case OutGoingGood
    case OutGoingBad
    case Empty
}

class Arrow {
    var Direct: Direction
    var State: State
    init() {
        Direct = .ToUp
        State = .UpComing
    }
    
    init(random: Bool, empty: Bool){
        Direct = .ToDown
        State = .UpComing
        if empty {
            State = .Empty
        }
        if (random){
            let forDirect = Int(arc4random_uniform(4))
            switch (forDirect){
            case 0:
                Direct = .ToUp
            case 1:
                Direct = .ToDown
            case 2:
                Direct = .ToLeft
            case 3:
                Direct = .ToRight
            default:
                Direct = .ToDown
            }
        }
    }
}

class TwerkGame {
    var Arrows = [Arrow]()
    var Score: Int
    var Lifes: Int
    var NumOfCurArrow: Int
    var ifGame: Bool
    //var ifReadyForAction: Bool
    
    init () {
        ifGame = false
        //ifReadyForAction = true
        for _ in 0...NUM_OF_ARROWS {
            Arrows.append(Arrow())
        }
        if NUM_OF_ARROWS%2 == 0{
            NumOfCurArrow = NUM_OF_ARROWS/2
        } else {
            NumOfCurArrow = (NUM_OF_ARROWS - 1)/2
        }
        Score = 0
        Lifes = 3
    }
    
    func NextTurn () {
        for i in 0...NUM_OF_ARROWS-1{
            Arrows[i] = Arrows[i + 1]
        }
        Arrows[NUM_OF_ARROWS] = Arrow(random: true, empty: false)
        NumOfCurArrow -= 1
    }
    
    func PrepareForGame () {
        Lifes = 3
        Score = 0
        for i in 0...NUM_OF_ARROWS {
            if (i < NUM_OF_ARROWS/2) {
                Arrows[i] = Arrow(random: true, empty: true)
            } else {
                Arrows[i] = Arrow(random: true, empty: false)
            }
        }
    }
    
    func PlayerEndedTurn (onPosition position: Direction) {
        //if (ifReadyForAction) {
            //ifReadyForAction = false
        if(ifGame == false) {
            ifGame = true
        }
        if (position == Arrows[NumOfCurArrow].Direct){
            Arrows[NumOfCurArrow].State = .OutGoingGood
            Score += 1
        } else {
            Arrows[NumOfCurArrow].State = .OutGoingBad
            Lifes -= 1
            if (Lifes <= 0){
                ifGame = false
            }
        }
        NumOfCurArrow += 1
        //}
    }
}
